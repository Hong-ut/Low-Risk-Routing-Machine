## Frontend:
- Raw intersection risk view: On the map of Toronto, plot points on all intersections and color code by risk (green, yellow, and red)
- Route risk view: On the route, plot points on all intersections and color code by risk

ID (location)
st name
logi
latitude
risk lvl

## Backend:

## Data:
